import 'package:tcs_dff_design_system/uikit/container/app_bar/default_app_bar.dart';

class HomeAppBar extends DefaultAppBar {
  const HomeAppBar({
    super.key,
    super.title = 'Home',
    super.showBackButton = false,
  });
}
