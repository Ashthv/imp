import 'package:tcs_dff_design_system/tcs_dff_design_system.dart';

class DemoSearchAppBar extends SearchAppBar {
  const DemoSearchAppBar({
    super.key,
    required super.controller,
  });
}
