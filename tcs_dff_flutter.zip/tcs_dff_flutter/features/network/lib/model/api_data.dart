class APIData {
  String? result;
  APIData({
    this.result,
  });
}
