class CardModel {
  CardModel({required this.title, required this.description});
  final String title;
  final String description;
}
