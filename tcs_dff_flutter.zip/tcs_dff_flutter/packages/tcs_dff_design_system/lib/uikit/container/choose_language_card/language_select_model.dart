class ChooseLanguageModel {
   String language;
   String localeText;
  bool isSelected;
  ChooseLanguageModel({
    required this.language,
    required this.localeText,
    required this.isSelected,
  });
}
