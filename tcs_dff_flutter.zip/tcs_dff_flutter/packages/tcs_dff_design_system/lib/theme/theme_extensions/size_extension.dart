import 'package:flutter/material.dart';

class AppSizeExtension extends ThemeExtension<AppSizeExtension> {
  final double sizePoint72;
  final double sizePoint7;
  final double sizePoint5;
  final double size0;
  final double size1;
  final double size2;
  final double size3;
  final double size4;
  final double size5;
  final double size6;
  final double size7;
  final double size8;
  final double size9;
  final double size10;
  final double size11;
  final double size12;
  final double size13;
  final double size14;
  final double size15;
  final double size16;
  final double size17;
  final double size18;
  final double size19;
  final double size20;
  final double size21;
  final double size22;
  final double size23;
  final double size24;
  final double size25;
  final double size26;
  final double size27;
  final double size28;
  final double size29;
  final double size30;
  final double size31;
  final double size32;
  final double size33;
  final double size34;
  final double size35;
  final double size36;
  final double size37;
  final double size38;
  final double size39;
  final double size40;
  final double size41;
  final double size42;
  final double size43;
  final double size44;
  final double size45;
  final double size46;
  final double size47;
  final double size48;
  final double size49;
  final double size50;
  final double size51;
  final double size52;
  final double size53;
  final double size54;
  final double size55;
  final double size56;
  final double size57;
  final double size58;
  final double size59;
  final double size60;
  final double size61;
  final double size62;
  final double size63;
  final double size64;
  final double size65;
  final double size66;
  final double size67;
  final double size68;
  final double size69;
  final double size70;
  final double size71;
  final double size72;
  final double size73;
  final double size74;
  final double size75;
  final double size76;
  final double size77;
  final double size78;
  final double size79;
  final double size80;
  final double size81;
  final double size82;
  final double size83;
  final double size84;
  final double size85;
  final double size86;
  final double size87;
  final double size88;
  final double size89;
  final double size90;
  final double size91;
  final double size92;
  final double size93;
  final double size94;
  final double size95;
  final double size96;
  final double size97;
  final double size98;
  final double size99;
  final double size100;
  final double size101;
  final double size102;
  final double size103;
  final double size104;
  final double size105;
  final double size106;
  final double size107;
  final double size108;
  final double size109;
  final double size110;
  final double size111;
  final double size112;
  final double size113;
  final double size114;
  final double size115;
  final double size116;
  final double size117;
  final double size118;
  final double size119;
  final double size120;
  final double size121;
  final double size122;
  final double size123;
  final double size124;
  final double size125;
  final double size126;
  final double size127;
  final double size128;
  final double size129;
  final double size130;
  final double size131;
  final double size132;
  final double size133;
  final double size134;
  final double size135;
  final double size136;
  final double size137;
  final double size138;
  final double size139;
  final double size140;
  final double size141;
  final double size142;
  final double size143;
  final double size144;
  final double size145;
  final double size146;
  final double size147;
  final double size148;
  final double size149;
  final double size150;
  final double size151;
  final double size152;
  final double size153;
  final double size154;
  final double size155;
  final double size156;
  final double size157;
  final double size158;
  final double size159;
  final double size160;
  final double size161;
  final double size162;
  final double size163;
  final double size164;
  final double size165;
  final double size166;
  final double size167;
  final double size168;
  final double size169;
  final double size170;
  final double size171;
  final double size172;
  final double size173;
  final double size174;
  final double size175;
  final double size176;
  final double size177;
  final double size178;
  final double size179;
  final double size180;
  final double size181;
  final double size182;
  final double size183;
  final double size184;
  final double size185;
  final double size186;
  final double size187;
  final double size188;
  final double size189;
  final double size190;
  final double size191;
  final double size192;
  final double size193;
  final double size194;
  final double size195;
  final double size196;
  final double size197;
  final double size198;
  final double size199;
  final double size200;
  final double size201;
  final double size202;
  final double size203;
  final double size204;
  final double size205;
  final double size206;
  final double size207;
  final double size208;
  final double size209;
  final double size210;
  final double size211;
  final double size212;
  final double size213;
  final double size214;
  final double size215;
  final double size216;
  final double size217;
  final double size218;
  final double size219;
  final double size220;
  final double size221;
  final double size222;
  final double size223;
  final double size224;
  final double size225;
  final double size226;
  final double size227;
  final double size228;
  final double size229;
  final double size230;
  final double size231;
  final double size232;
  final double size233;
  final double size234;
  final double size235;
  final double size236;
  final double size237;
  final double size238;
  final double size239;
  final double size240;
  final double size241;
  final double size242;
  final double size243;
  final double size244;
  final double size245;
  final double size246;
  final double size247;
  final double size248;
  final double size249;
  final double size250;
  final double size251;
  final double size252;
  final double size253;
  final double size254;
  final double size255;
  final double size256;
  final double size257;
  final double size258;
  final double size259;
  final double size260;
  final double size261;
  final double size262;
  final double size263;
  final double size264;
  final double size265;
  final double size266;
  final double size267;
  final double size268;
  final double size269;
  final double size270;
  final double size271;
  final double size272;
  final double size273;
  final double size274;
  final double size275;
  final double size276;
  final double size277;
  final double size278;
  final double size279;
  final double size280;
  final double size281;
  final double size282;
  final double size283;
  final double size284;
  final double size285;
  final double size286;
  final double size287;
  final double size288;
  final double size289;
  final double size290;
  final double size291;
  final double size292;
  final double size293;
  final double size294;
  final double size295;
  final double size296;
  final double size297;
  final double size298;
  final double size299;
  final double size300;
  final double size301;
  final double size302;
  final double size303;
  final double size304;
  final double size305;
  final double size306;
  final double size307;
  final double size308;
  final double size309;
  final double size310;
  final double size311;
  final double size312;
  final double size313;
  final double size314;
  final double size315;
  final double size316;
  final double size317;
  final double size318;
  final double size319;
  final double size320;
  final double size321;
  final double size322;
  final double size323;
  final double size324;
  final double size325;
  final double size326;
  final double size327;
  final double size328;
  final double size329;
  final double size330;
  final double size331;
  final double size332;
  final double size333;
  final double size334;
  final double size335;
  final double size336;
  final double size337;
  final double size338;
  final double size339;
  final double size340;
  final double size341;
  final double size342;
  final double size343;
  final double size344;
  final double size345;
  final double size346;
  final double size347;
  final double size348;
  final double size349;
  final double size350;
  final double size351;
  final double size352;
  final double size353;
  final double size354;
  final double size355;
  final double size356;
  final double size357;
  final double size358;
  final double size359;
  final double size360;
  final double size361;
  final double size362;
  final double size363;
  final double size364;
  final double size365;
  final double size366;
  final double size367;
  final double size368;
  final double size369;
  final double size370;
  final double size371;
  final double size372;
  final double size373;
  final double size374;
  final double size375;
  final double size376;
  final double size377;
  final double size378;
  final double size379;
  final double size380;
  final double size381;
  final double size382;
  final double size383;
  final double size384;
  final double size385;
  final double size386;
  final double size387;
  final double size388;
  final double size389;
  final double size390;
  final double size391;
  final double size392;
  final double size393;
  final double size394;
  final double size395;
  final double size396;
  final double size397;
  final double size398;
  final double size399;
  final double size400;
  final double size401;
  final double size402;
  final double size403;
  final double size404;
  final double size405;
  final double size406;
  final double size407;
  final double size408;
  final double size409;
  final double size410;
  final double size411;
  final double size412;
  final double size413;
  final double size414;
  final double size415;
  final double size416;
  final double size417;
  final double size418;
  final double size419;
  final double size420;
  final double size421;
  final double size422;
  final double size423;
  final double size424;
  final double size425;
  final double size426;
  final double size427;
  final double size428;
  final double size429;
  final double size430;
  final double size431;
  final double size432;
  final double size433;
  final double size434;
  final double size435;
  final double size436;
  final double size437;
  final double size438;
  final double size439;
  final double size440;
  final double size441;
  final double size442;
  final double size443;
  final double size444;
  final double size445;
  final double size446;
  final double size447;
  final double size448;
  final double size449;
  final double size450;
  final double size451;
  final double size452;
  final double size453;
  final double size454;
  final double size455;
  final double size456;
  final double size457;
  final double size458;
  final double size459;
  final double size460;
  final double size461;
  final double size462;
  final double size463;
  final double size464;
  final double size465;
  final double size466;
  final double size467;
  final double size468;
  final double size469;
  final double size470;
  final double size471;
  final double size472;
  final double size473;
  final double size474;
  final double size475;
  final double size476;
  final double size477;
  final double size478;
  final double size479;
  final double size480;
  final double size481;
  final double size482;
  final double size483;
  final double size484;
  final double size485;
  final double size486;
  final double size487;
  final double size488;
  final double size489;
  final double size490;
  final double size491;
  final double size492;
  final double size493;
  final double size494;
  final double size495;
  final double size496;
  final double size497;
  final double size498;
  final double size499;
  final double size500;
  final double size501;
  final double size502;
  final double size503;
  final double size504;
  final double size505;
  final double size506;
  final double size507;
  final double size508;
  final double size509;
  final double size510;
  final double size511;
  final double size512;
  final double size513;
  final double size514;
  final double size515;
  final double size516;
  final double size517;
  final double size518;
  final double size519;
  final double size520;
  final double size521;
  final double size522;
  final double size523;
  final double size524;
  final double size525;
  final double size526;
  final double size527;
  final double size528;
  final double size529;
  final double size530;
  final double size531;
  final double size532;
  final double size533;
  final double size534;
  final double size535;
  final double size536;
  final double size537;
  final double size538;
  final double size539;
  final double size540;
  final double size541;
  final double size542;
  final double size543;
  final double size544;
  final double size545;
  final double size546;
  final double size547;
  final double size548;
  final double size549;
  final double size550;
  final double size551;
  final double size552;
  final double size553;
  final double size554;
  final double size555;
  final double size556;
  final double size557;
  final double size558;
  final double size559;
  final double size560;
  final double size561;
  final double size562;
  final double size563;
  final double size564;
  final double size565;
  final double size566;
  final double size567;
  final double size568;
  final double size569;
  final double size570;
  final double size571;
  final double size572;
  final double size573;
  final double size574;
  final double size575;
  final double size576;
  final double size577;
  final double size578;
  final double size579;
  final double size580;
  final double size581;
  final double size582;
  final double size583;
  final double size584;
  final double size585;
  final double size586;
  final double size587;
  final double size588;
  final double size589;
  final double size590;
  final double size591;
  final double size592;
  final double size593;
  final double size594;
  final double size595;
  final double size596;
  final double size597;
  final double size598;
  final double size599;
  final double size600;
  final double size601;
  final double size602;
  final double size603;
  final double size604;
  final double size605;
  final double size606;
  final double size607;
  final double size608;
  final double size609;
  final double size610;
  final double size611;
  final double size612;
  final double size613;
  final double size614;
  final double size615;
  final double size616;
  final double size617;
  final double size618;
  final double size619;
  final double size620;
  final double size621;
  final double size622;
  final double size623;
  final double size624;
  final double size625;
  final double size626;
  final double size627;
  final double size628;
  final double size629;
  final double size630;
  final double size631;
  final double size632;
  final double size633;
  final double size634;
  final double size635;
  final double size636;
  final double size637;
  final double size638;
  final double size639;
  final double size640;
  final double size641;
  final double size642;
  final double size643;
  final double size644;
  final double size645;
  final double size646;
  final double size647;
  final double size648;
  final double size649;
  final double size650;
  final double size651;
  final double size652;
  final double size653;
  final double size654;
  final double size655;
  final double size656;
  final double size657;
  final double size658;
  final double size659;
  final double size660;
  final double size661;
  final double size662;
  final double size663;
  final double size664;
  final double size665;
  final double size666;
  final double size667;
  final double size668;
  final double size669;
  final double size670;
  final double size671;
  final double size672;
  final double size673;
  final double size674;
  final double size675;
  final double size676;
  final double size677;
  final double size678;
  final double size679;
  final double size680;
  final double size681;
  final double size682;
  final double size683;
  final double size684;
  final double size685;
  final double size686;
  final double size687;
  final double size688;
  final double size689;
  final double size690;
  final double size691;
  final double size692;
  final double size693;
  final double size694;
  final double size695;
  final double size696;
  final double size697;
  final double size698;
  final double size699;
  final double size700;
  final double size701;
  final double size702;
  final double size703;
  final double size704;
  final double size705;
  final double size706;
  final double size707;
  final double size708;
  final double size709;
  final double size710;
  final double size711;
  final double size712;
  final double size713;
  final double size714;
  final double size715;
  final double size716;
  final double size717;
  final double size718;
  final double size719;
  final double size720;
  final double size721;
  final double size722;
  final double size723;
  final double size724;
  final double size725;
  final double size726;
  final double size727;
  final double size728;
  final double size729;
  final double size730;
  final double size731;
  final double size732;
  final double size733;
  final double size734;
  final double size735;
  final double size736;
  final double size737;
  final double size738;
  final double size739;
  final double size740;
  final double size741;
  final double size742;
  final double size743;
  final double size744;
  final double size745;
  final double size746;
  final double size747;
  final double size748;
  final double size749;
  final double size750;
  final double size751;
  final double size752;
  final double size753;
  final double size754;
  final double size755;
  final double size756;
  final double size757;
  final double size758;
  final double size759;
  final double size760;
  final double size761;
  final double size762;
  final double size763;
  final double size764;
  final double size765;
  final double size766;
  final double size767;
  final double size768;
  final double size769;
  final double size770;
  final double size771;
  final double size772;
  final double size773;
  final double size774;
  final double size775;
  final double size776;
  final double size777;
  final double size778;
  final double size779;
  final double size780;
  final double size781;
  final double size782;
  final double size783;
  final double size784;
  final double size785;
  final double size786;
  final double size787;
  final double size788;
  final double size789;
  final double size790;
  final double size791;
  final double size792;
  final double size793;
  final double size794;
  final double size795;
  final double size796;
  final double size797;
  final double size798;
  final double size799;
  final double size800;
  final double size801;
  final double size802;
  final double size803;
  final double size804;
  final double size805;
  final double size806;
  final double size807;
  final double size808;
  final double size809;
  final double size810;
  final double size811;
  final double size812;
  final double size813;
  final double size814;
  final double size815;
  final double size816;
  final double size817;
  final double size818;
  final double size819;
  final double size820;
  final double size821;
  final double size822;
  final double size823;
  final double size824;
  final double size825;
  final double size826;
  final double size827;
  final double size828;
  final double size829;
  final double size830;
  final double size831;
  final double size832;
  final double size833;
  final double size834;
  final double size835;
  final double size836;
  final double size837;
  final double size838;
  final double size839;
  final double size840;
  final double size841;
  final double size842;
  final double size843;
  final double size844;
  final double size845;
  final double size846;
  final double size847;
  final double size848;
  final double size849;
  final double size850;
  final double size851;
  final double size852;
  final double size853;
  final double size854;
  final double size855;
  final double size856;
  final double size857;
  final double size858;
  final double size859;
  final double size860;
  final double size861;
  final double size862;
  final double size863;
  final double size864;
  final double size865;
  final double size866;
  final double size867;
  final double size868;
  final double size869;
  final double size870;
  final double size871;
  final double size872;
  final double size873;
  final double size874;
  final double size875;
  final double size876;
  final double size877;
  final double size878;
  final double size879;
  final double size880;
  final double size881;
  final double size882;
  final double size883;
  final double size884;
  final double size885;
  final double size886;
  final double size887;
  final double size888;
  final double size889;
  final double size890;
  final double size891;
  final double size892;
  final double size893;
  final double size894;
  final double size895;
  final double size896;
  final double size897;
  final double size898;
  final double size899;
  final double size900;
  final double size901;
  final double size902;
  final double size903;
  final double size904;
  final double size905;
  final double size906;
  final double size907;
  final double size908;
  final double size909;
  final double size910;
  final double size911;
  final double size912;
  final double size913;
  final double size914;
  final double size915;
  final double size916;
  final double size917;
  final double size918;
  final double size919;
  final double size920;
  final double size921;
  final double size922;
  final double size923;
  final double size924;
  final double size925;
  final double size926;
  final double size927;
  final double size928;
  final double size929;
  final double size930;
  final double size931;
  final double size932;
  final double size933;
  final double size934;
  final double size935;
  final double size936;
  final double size937;
  final double size938;
  final double size939;
  final double size940;
  final double size941;
  final double size942;
  final double size943;
  final double size944;
  final double size945;
  final double size946;
  final double size947;
  final double size948;
  final double size949;
  final double size950;
  final double size951;
  final double size952;
  final double size953;
  final double size954;
  final double size955;
  final double size956;
  final double size957;
  final double size958;
  final double size959;
  final double size960;
  final double size961;
  final double size962;
  final double size963;
  final double size964;
  final double size965;
  final double size966;
  final double size967;
  final double size968;
  final double size969;
  final double size970;
  final double size971;
  final double size972;
  final double size973;
  final double size974;
  final double size975;
  final double size976;
  final double size977;
  final double size978;
  final double size979;
  final double size980;
  final double size981;
  final double size982;
  final double size983;
  final double size984;
  final double size985;
  final double size986;
  final double size987;
  final double size988;
  final double size989;
  final double size990;
  final double size991;
  final double size992;
  final double size993;
  final double size994;
  final double size995;
  final double size996;
  final double size997;
  final double size998;
  final double size999;

  AppSizeExtension({
    required this.sizePoint72,
    required this.sizePoint7,
    required this.sizePoint5,
    required this.size0,
    required this.size1,
    required this.size2,
    required this.size3,
    required this.size4,
    required this.size5,
    required this.size6,
    required this.size7,
    required this.size8,
    required this.size9,
    required this.size10,
    required this.size11,
    required this.size12,
    required this.size13,
    required this.size14,
    required this.size15,
    required this.size16,
    required this.size17,
    required this.size18,
    required this.size19,
    required this.size20,
    required this.size21,
    required this.size22,
    required this.size23,
    required this.size24,
    required this.size25,
    required this.size26,
    required this.size27,
    required this.size28,
    required this.size29,
    required this.size30,
    required this.size31,
    required this.size32,
    required this.size33,
    required this.size34,
    required this.size35,
    required this.size36,
    required this.size37,
    required this.size38,
    required this.size39,
    required this.size40,
    required this.size41,
    required this.size42,
    required this.size43,
    required this.size44,
    required this.size45,
    required this.size46,
    required this.size47,
    required this.size48,
    required this.size49,
    required this.size50,
    required this.size51,
    required this.size52,
    required this.size53,
    required this.size54,
    required this.size55,
    required this.size56,
    required this.size57,
    required this.size58,
    required this.size59,
    required this.size60,
    required this.size61,
    required this.size62,
    required this.size63,
    required this.size64,
    required this.size65,
    required this.size66,
    required this.size67,
    required this.size68,
    required this.size69,
    required this.size70,
    required this.size71,
    required this.size72,
    required this.size73,
    required this.size74,
    required this.size75,
    required this.size76,
    required this.size77,
    required this.size78,
    required this.size79,
    required this.size80,
    required this.size81,
    required this.size82,
    required this.size83,
    required this.size84,
    required this.size85,
    required this.size86,
    required this.size87,
    required this.size88,
    required this.size89,
    required this.size90,
    required this.size91,
    required this.size92,
    required this.size93,
    required this.size94,
    required this.size95,
    required this.size96,
    required this.size97,
    required this.size98,
    required this.size99,
    required this.size100,
    required this.size101,
    required this.size102,
    required this.size103,
    required this.size104,
    required this.size105,
    required this.size106,
    required this.size107,
    required this.size108,
    required this.size109,
    required this.size110,
    required this.size111,
    required this.size112,
    required this.size113,
    required this.size114,
    required this.size115,
    required this.size116,
    required this.size117,
    required this.size118,
    required this.size119,
    required this.size120,
    required this.size121,
    required this.size122,
    required this.size123,
    required this.size124,
    required this.size125,
    required this.size126,
    required this.size127,
    required this.size128,
    required this.size129,
    required this.size130,
    required this.size131,
    required this.size132,
    required this.size133,
    required this.size134,
    required this.size135,
    required this.size136,
    required this.size137,
    required this.size138,
    required this.size139,
    required this.size140,
    required this.size141,
    required this.size142,
    required this.size143,
    required this.size144,
    required this.size145,
    required this.size146,
    required this.size147,
    required this.size148,
    required this.size149,
    required this.size150,
    required this.size151,
    required this.size152,
    required this.size153,
    required this.size154,
    required this.size155,
    required this.size156,
    required this.size157,
    required this.size158,
    required this.size159,
    required this.size160,
    required this.size161,
    required this.size162,
    required this.size163,
    required this.size164,
    required this.size165,
    required this.size166,
    required this.size167,
    required this.size168,
    required this.size169,
    required this.size170,
    required this.size171,
    required this.size172,
    required this.size173,
    required this.size174,
    required this.size175,
    required this.size176,
    required this.size177,
    required this.size178,
    required this.size179,
    required this.size180,
    required this.size181,
    required this.size182,
    required this.size183,
    required this.size184,
    required this.size185,
    required this.size186,
    required this.size187,
    required this.size188,
    required this.size189,
    required this.size190,
    required this.size191,
    required this.size192,
    required this.size193,
    required this.size194,
    required this.size195,
    required this.size196,
    required this.size197,
    required this.size198,
    required this.size199,
    required this.size200,
    required this.size201,
    required this.size202,
    required this.size203,
    required this.size204,
    required this.size205,
    required this.size206,
    required this.size207,
    required this.size208,
    required this.size209,
    required this.size210,
    required this.size211,
    required this.size212,
    required this.size213,
    required this.size214,
    required this.size215,
    required this.size216,
    required this.size217,
    required this.size218,
    required this.size219,
    required this.size220,
    required this.size221,
    required this.size222,
    required this.size223,
    required this.size224,
    required this.size225,
    required this.size226,
    required this.size227,
    required this.size228,
    required this.size229,
    required this.size230,
    required this.size231,
    required this.size232,
    required this.size233,
    required this.size234,
    required this.size235,
    required this.size236,
    required this.size237,
    required this.size238,
    required this.size239,
    required this.size240,
    required this.size241,
    required this.size242,
    required this.size243,
    required this.size244,
    required this.size245,
    required this.size246,
    required this.size247,
    required this.size248,
    required this.size249,
    required this.size250,
    required this.size251,
    required this.size252,
    required this.size253,
    required this.size254,
    required this.size255,
    required this.size256,
    required this.size257,
    required this.size258,
    required this.size259,
    required this.size260,
    required this.size261,
    required this.size262,
    required this.size263,
    required this.size264,
    required this.size265,
    required this.size266,
    required this.size267,
    required this.size268,
    required this.size269,
    required this.size270,
    required this.size271,
    required this.size272,
    required this.size273,
    required this.size274,
    required this.size275,
    required this.size276,
    required this.size277,
    required this.size278,
    required this.size279,
    required this.size280,
    required this.size281,
    required this.size282,
    required this.size283,
    required this.size284,
    required this.size285,
    required this.size286,
    required this.size287,
    required this.size288,
    required this.size289,
    required this.size290,
    required this.size291,
    required this.size292,
    required this.size293,
    required this.size294,
    required this.size295,
    required this.size296,
    required this.size297,
    required this.size298,
    required this.size299,
    required this.size300,
    required this.size301,
    required this.size302,
    required this.size303,
    required this.size304,
    required this.size305,
    required this.size306,
    required this.size307,
    required this.size308,
    required this.size309,
    required this.size310,
    required this.size311,
    required this.size312,
    required this.size313,
    required this.size314,
    required this.size315,
    required this.size316,
    required this.size317,
    required this.size318,
    required this.size319,
    required this.size320,
    required this.size321,
    required this.size322,
    required this.size323,
    required this.size324,
    required this.size325,
    required this.size326,
    required this.size327,
    required this.size328,
    required this.size329,
    required this.size330,
    required this.size331,
    required this.size332,
    required this.size333,
    required this.size334,
    required this.size335,
    required this.size336,
    required this.size337,
    required this.size338,
    required this.size339,
    required this.size340,
    required this.size341,
    required this.size342,
    required this.size343,
    required this.size344,
    required this.size345,
    required this.size346,
    required this.size347,
    required this.size348,
    required this.size349,
    required this.size350,
    required this.size351,
    required this.size352,
    required this.size353,
    required this.size354,
    required this.size355,
    required this.size356,
    required this.size357,
    required this.size358,
    required this.size359,
    required this.size360,
    required this.size361,
    required this.size362,
    required this.size363,
    required this.size364,
    required this.size365,
    required this.size366,
    required this.size367,
    required this.size368,
    required this.size369,
    required this.size370,
    required this.size371,
    required this.size372,
    required this.size373,
    required this.size374,
    required this.size375,
    required this.size376,
    required this.size377,
    required this.size378,
    required this.size379,
    required this.size380,
    required this.size381,
    required this.size382,
    required this.size383,
    required this.size384,
    required this.size385,
    required this.size386,
    required this.size387,
    required this.size388,
    required this.size389,
    required this.size390,
    required this.size391,
    required this.size392,
    required this.size393,
    required this.size394,
    required this.size395,
    required this.size396,
    required this.size397,
    required this.size398,
    required this.size399,
    required this.size400,
    required this.size401,
    required this.size402,
    required this.size403,
    required this.size404,
    required this.size405,
    required this.size406,
    required this.size407,
    required this.size408,
    required this.size409,
    required this.size410,
    required this.size411,
    required this.size412,
    required this.size413,
    required this.size414,
    required this.size415,
    required this.size416,
    required this.size417,
    required this.size418,
    required this.size419,
    required this.size420,
    required this.size421,
    required this.size422,
    required this.size423,
    required this.size424,
    required this.size425,
    required this.size426,
    required this.size427,
    required this.size428,
    required this.size429,
    required this.size430,
    required this.size431,
    required this.size432,
    required this.size433,
    required this.size434,
    required this.size435,
    required this.size436,
    required this.size437,
    required this.size438,
    required this.size439,
    required this.size440,
    required this.size441,
    required this.size442,
    required this.size443,
    required this.size444,
    required this.size445,
    required this.size446,
    required this.size447,
    required this.size448,
    required this.size449,
    required this.size450,
    required this.size451,
    required this.size452,
    required this.size453,
    required this.size454,
    required this.size455,
    required this.size456,
    required this.size457,
    required this.size458,
    required this.size459,
    required this.size460,
    required this.size461,
    required this.size462,
    required this.size463,
    required this.size464,
    required this.size465,
    required this.size466,
    required this.size467,
    required this.size468,
    required this.size469,
    required this.size470,
    required this.size471,
    required this.size472,
    required this.size473,
    required this.size474,
    required this.size475,
    required this.size476,
    required this.size477,
    required this.size478,
    required this.size479,
    required this.size480,
    required this.size481,
    required this.size482,
    required this.size483,
    required this.size484,
    required this.size485,
    required this.size486,
    required this.size487,
    required this.size488,
    required this.size489,
    required this.size490,
    required this.size491,
    required this.size492,
    required this.size493,
    required this.size494,
    required this.size495,
    required this.size496,
    required this.size497,
    required this.size498,
    required this.size499,
    required this.size500,
    required this.size501,
    required this.size502,
    required this.size503,
    required this.size504,
    required this.size505,
    required this.size506,
    required this.size507,
    required this.size508,
    required this.size509,
    required this.size510,
    required this.size511,
    required this.size512,
    required this.size513,
    required this.size514,
    required this.size515,
    required this.size516,
    required this.size517,
    required this.size518,
    required this.size519,
    required this.size520,
    required this.size521,
    required this.size522,
    required this.size523,
    required this.size524,
    required this.size525,
    required this.size526,
    required this.size527,
    required this.size528,
    required this.size529,
    required this.size530,
    required this.size531,
    required this.size532,
    required this.size533,
    required this.size534,
    required this.size535,
    required this.size536,
    required this.size537,
    required this.size538,
    required this.size539,
    required this.size540,
    required this.size541,
    required this.size542,
    required this.size543,
    required this.size544,
    required this.size545,
    required this.size546,
    required this.size547,
    required this.size548,
    required this.size549,
    required this.size550,
    required this.size551,
    required this.size552,
    required this.size553,
    required this.size554,
    required this.size555,
    required this.size556,
    required this.size557,
    required this.size558,
    required this.size559,
    required this.size560,
    required this.size561,
    required this.size562,
    required this.size563,
    required this.size564,
    required this.size565,
    required this.size566,
    required this.size567,
    required this.size568,
    required this.size569,
    required this.size570,
    required this.size571,
    required this.size572,
    required this.size573,
    required this.size574,
    required this.size575,
    required this.size576,
    required this.size577,
    required this.size578,
    required this.size579,
    required this.size580,
    required this.size581,
    required this.size582,
    required this.size583,
    required this.size584,
    required this.size585,
    required this.size586,
    required this.size587,
    required this.size588,
    required this.size589,
    required this.size590,
    required this.size591,
    required this.size592,
    required this.size593,
    required this.size594,
    required this.size595,
    required this.size596,
    required this.size597,
    required this.size598,
    required this.size599,
    required this.size600,
    required this.size601,
    required this.size602,
    required this.size603,
    required this.size604,
    required this.size605,
    required this.size606,
    required this.size607,
    required this.size608,
    required this.size609,
    required this.size610,
    required this.size611,
    required this.size612,
    required this.size613,
    required this.size614,
    required this.size615,
    required this.size616,
    required this.size617,
    required this.size618,
    required this.size619,
    required this.size620,
    required this.size621,
    required this.size622,
    required this.size623,
    required this.size624,
    required this.size625,
    required this.size626,
    required this.size627,
    required this.size628,
    required this.size629,
    required this.size630,
    required this.size631,
    required this.size632,
    required this.size633,
    required this.size634,
    required this.size635,
    required this.size636,
    required this.size637,
    required this.size638,
    required this.size639,
    required this.size640,
    required this.size641,
    required this.size642,
    required this.size643,
    required this.size644,
    required this.size645,
    required this.size646,
    required this.size647,
    required this.size648,
    required this.size649,
    required this.size650,
    required this.size651,
    required this.size652,
    required this.size653,
    required this.size654,
    required this.size655,
    required this.size656,
    required this.size657,
    required this.size658,
    required this.size659,
    required this.size660,
    required this.size661,
    required this.size662,
    required this.size663,
    required this.size664,
    required this.size665,
    required this.size666,
    required this.size667,
    required this.size668,
    required this.size669,
    required this.size670,
    required this.size671,
    required this.size672,
    required this.size673,
    required this.size674,
    required this.size675,
    required this.size676,
    required this.size677,
    required this.size678,
    required this.size679,
    required this.size680,
    required this.size681,
    required this.size682,
    required this.size683,
    required this.size684,
    required this.size685,
    required this.size686,
    required this.size687,
    required this.size688,
    required this.size689,
    required this.size690,
    required this.size691,
    required this.size692,
    required this.size693,
    required this.size694,
    required this.size695,
    required this.size696,
    required this.size697,
    required this.size698,
    required this.size699,
    required this.size700,
    required this.size701,
    required this.size702,
    required this.size703,
    required this.size704,
    required this.size705,
    required this.size706,
    required this.size707,
    required this.size708,
    required this.size709,
    required this.size710,
    required this.size711,
    required this.size712,
    required this.size713,
    required this.size714,
    required this.size715,
    required this.size716,
    required this.size717,
    required this.size718,
    required this.size719,
    required this.size720,
    required this.size721,
    required this.size722,
    required this.size723,
    required this.size724,
    required this.size725,
    required this.size726,
    required this.size727,
    required this.size728,
    required this.size729,
    required this.size730,
    required this.size731,
    required this.size732,
    required this.size733,
    required this.size734,
    required this.size735,
    required this.size736,
    required this.size737,
    required this.size738,
    required this.size739,
    required this.size740,
    required this.size741,
    required this.size742,
    required this.size743,
    required this.size744,
    required this.size745,
    required this.size746,
    required this.size747,
    required this.size748,
    required this.size749,
    required this.size750,
    required this.size751,
    required this.size752,
    required this.size753,
    required this.size754,
    required this.size755,
    required this.size756,
    required this.size757,
    required this.size758,
    required this.size759,
    required this.size760,
    required this.size761,
    required this.size762,
    required this.size763,
    required this.size764,
    required this.size765,
    required this.size766,
    required this.size767,
    required this.size768,
    required this.size769,
    required this.size770,
    required this.size771,
    required this.size772,
    required this.size773,
    required this.size774,
    required this.size775,
    required this.size776,
    required this.size777,
    required this.size778,
    required this.size779,
    required this.size780,
    required this.size781,
    required this.size782,
    required this.size783,
    required this.size784,
    required this.size785,
    required this.size786,
    required this.size787,
    required this.size788,
    required this.size789,
    required this.size790,
    required this.size791,
    required this.size792,
    required this.size793,
    required this.size794,
    required this.size795,
    required this.size796,
    required this.size797,
    required this.size798,
    required this.size799,
    required this.size800,
    required this.size801,
    required this.size802,
    required this.size803,
    required this.size804,
    required this.size805,
    required this.size806,
    required this.size807,
    required this.size808,
    required this.size809,
    required this.size810,
    required this.size811,
    required this.size812,
    required this.size813,
    required this.size814,
    required this.size815,
    required this.size816,
    required this.size817,
    required this.size818,
    required this.size819,
    required this.size820,
    required this.size821,
    required this.size822,
    required this.size823,
    required this.size824,
    required this.size825,
    required this.size826,
    required this.size827,
    required this.size828,
    required this.size829,
    required this.size830,
    required this.size831,
    required this.size832,
    required this.size833,
    required this.size834,
    required this.size835,
    required this.size836,
    required this.size837,
    required this.size838,
    required this.size839,
    required this.size840,
    required this.size841,
    required this.size842,
    required this.size843,
    required this.size844,
    required this.size845,
    required this.size846,
    required this.size847,
    required this.size848,
    required this.size849,
    required this.size850,
    required this.size851,
    required this.size852,
    required this.size853,
    required this.size854,
    required this.size855,
    required this.size856,
    required this.size857,
    required this.size858,
    required this.size859,
    required this.size860,
    required this.size861,
    required this.size862,
    required this.size863,
    required this.size864,
    required this.size865,
    required this.size866,
    required this.size867,
    required this.size868,
    required this.size869,
    required this.size870,
    required this.size871,
    required this.size872,
    required this.size873,
    required this.size874,
    required this.size875,
    required this.size876,
    required this.size877,
    required this.size878,
    required this.size879,
    required this.size880,
    required this.size881,
    required this.size882,
    required this.size883,
    required this.size884,
    required this.size885,
    required this.size886,
    required this.size887,
    required this.size888,
    required this.size889,
    required this.size890,
    required this.size891,
    required this.size892,
    required this.size893,
    required this.size894,
    required this.size895,
    required this.size896,
    required this.size897,
    required this.size898,
    required this.size899,
    required this.size900,
    required this.size901,
    required this.size902,
    required this.size903,
    required this.size904,
    required this.size905,
    required this.size906,
    required this.size907,
    required this.size908,
    required this.size909,
    required this.size910,
    required this.size911,
    required this.size912,
    required this.size913,
    required this.size914,
    required this.size915,
    required this.size916,
    required this.size917,
    required this.size918,
    required this.size919,
    required this.size920,
    required this.size921,
    required this.size922,
    required this.size923,
    required this.size924,
    required this.size925,
    required this.size926,
    required this.size927,
    required this.size928,
    required this.size929,
    required this.size930,
    required this.size931,
    required this.size932,
    required this.size933,
    required this.size934,
    required this.size935,
    required this.size936,
    required this.size937,
    required this.size938,
    required this.size939,
    required this.size940,
    required this.size941,
    required this.size942,
    required this.size943,
    required this.size944,
    required this.size945,
    required this.size946,
    required this.size947,
    required this.size948,
    required this.size949,
    required this.size950,
    required this.size951,
    required this.size952,
    required this.size953,
    required this.size954,
    required this.size955,
    required this.size956,
    required this.size957,
    required this.size958,
    required this.size959,
    required this.size960,
    required this.size961,
    required this.size962,
    required this.size963,
    required this.size964,
    required this.size965,
    required this.size966,
    required this.size967,
    required this.size968,
    required this.size969,
    required this.size970,
    required this.size971,
    required this.size972,
    required this.size973,
    required this.size974,
    required this.size975,
    required this.size976,
    required this.size977,
    required this.size978,
    required this.size979,
    required this.size980,
    required this.size981,
    required this.size982,
    required this.size983,
    required this.size984,
    required this.size985,
    required this.size986,
    required this.size987,
    required this.size988,
    required this.size989,
    required this.size990,
    required this.size991,
    required this.size992,
    required this.size993,
    required this.size994,
    required this.size995,
    required this.size996,
    required this.size997,
    required this.size998,
    required this.size999,
  });
  @override
  ThemeExtension<AppSizeExtension> copyWith({
    final double? size1,
    final double? size2,
    final double? size3,
    final double? size4,
    final double? size5,
    final double? size6,
    final double? size7,
    final double? size8,
    final double? size9,
    final double? size10,
    final double? size11,
    final double? size12,
    final double? size13,
    final double? size14,
    final double? size15,
    final double? size16,
    final double? size17,
    final double? size18,
    final double? size19,
    final double? size20,
    final double? size21,
    final double? size22,
    final double? size23,
    final double? size24,
    final double? size25,
    final double? size26,
    final double? size27,
    final double? size28,
    final double? size29,
    final double? size30,
    final double? size31,
    final double? size32,
    final double? size33,
    final double? size34,
    final double? size35,
    final double? size36,
    final double? size37,
    final double? size38,
    final double? size39,
    final double? size40,
    final double? size41,
    final double? size42,
    final double? size43,
    final double? size44,
    final double? size45,
    final double? size46,
    final double? size47,
    final double? size48,
    final double? size49,
    final double? size50,
    final double? size51,
    final double? size52,
    final double? size53,
    final double? size54,
    final double? size55,
    final double? size56,
    final double? size57,
    final double? size58,
    final double? size59,
    final double? size60,
    final double? size61,
    final double? size62,
    final double? size63,
    final double? size64,
    final double? size65,
    final double? size66,
    final double? size67,
    final double? size68,
    final double? size69,
    final double? size70,
    final double? size71,
    final double? size72,
    final double? size73,
    final double? size74,
    final double? size75,
    final double? size76,
    final double? size77,
    final double? size78,
    final double? size79,
    final double? size80,
    final double? size81,
    final double? size82,
    final double? size83,
    final double? size84,
    final double? size85,
    final double? size86,
    final double? size87,
    final double? size88,
    final double? size89,
    final double? size90,
    final double? size91,
    final double? size92,
    final double? size93,
    final double? size94,
    final double? size95,
    final double? size96,
    final double? size97,
    final double? size98,
    final double? size99,
    final double? size100,
    final double? size101,
    final double? size102,
    final double? size103,
    final double? size104,
    final double? size105,
    final double? size106,
    final double? size107,
    final double? size108,
    final double? size109,
    final double? size110,
    final double? size111,
    final double? size112,
    final double? size113,
    final double? size114,
    final double? size115,
    final double? size116,
    final double? size117,
    final double? size118,
    final double? size119,
    final double? size120,
    final double? size121,
    final double? size122,
    final double? size123,
    final double? size124,
    final double? size125,
    final double? size126,
    final double? size127,
    final double? size128,
    final double? size129,
    final double? size130,
    final double? size131,
    final double? size132,
    final double? size133,
    final double? size134,
    final double? size135,
    final double? size136,
    final double? size137,
    final double? size138,
    final double? size139,
    final double? size140,
    final double? size141,
    final double? size142,
    final double? size143,
    final double? size144,
    final double? size145,
    final double? size146,
    final double? size147,
    final double? size148,
    final double? size149,
    final double? size150,
    final double? size151,
    final double? size152,
    final double? size153,
    final double? size154,
    final double? size155,
    final double? size156,
    final double? size157,
    final double? size158,
    final double? size159,
    final double? size160,
    final double? size161,
    final double? size162,
    final double? size163,
    final double? size164,
    final double? size165,
    final double? size166,
    final double? size167,
    final double? size168,
    final double? size169,
    final double? size170,
    final double? size171,
    final double? size172,
    final double? size173,
    final double? size174,
    final double? size175,
    final double? size176,
    final double? size177,
    final double? size178,
    final double? size179,
    final double? size180,
    final double? size181,
    final double? size182,
    final double? size183,
    final double? size184,
    final double? size185,
    final double? size186,
    final double? size187,
    final double? size188,
    final double? size189,
    final double? size190,
    final double? size191,
    final double? size192,
    final double? size193,
    final double? size194,
    final double? size195,
    final double? size196,
    final double? size197,
    final double? size198,
    final double? size199,
    final double? size200,
    final double? size201,
    final double? size202,
    final double? size203,
    final double? size204,
    final double? size205,
    final double? size206,
    final double? size207,
    final double? size208,
    final double? size209,
    final double? size210,
    final double? size211,
    final double? size212,
    final double? size213,
    final double? size214,
    final double? size215,
    final double? size216,
    final double? size217,
    final double? size218,
    final double? size219,
    final double? size220,
    final double? size221,
    final double? size222,
    final double? size223,
    final double? size224,
    final double? size225,
    final double? size226,
    final double? size227,
    final double? size228,
    final double? size229,
    final double? size230,
    final double? size231,
    final double? size232,
    final double? size233,
    final double? size234,
    final double? size235,
    final double? size236,
    final double? size237,
    final double? size238,
    final double? size239,
    final double? size240,
    final double? size241,
    final double? size242,
    final double? size243,
    final double? size244,
    final double? size245,
    final double? size246,
    final double? size247,
    final double? size248,
    final double? size249,
    final double? size250,
    final double? size251,
    final double? size252,
    final double? size253,
    final double? size254,
    final double? size255,
    final double? size256,
    final double? size257,
    final double? size258,
    final double? size259,
    final double? size260,
    final double? size261,
    final double? size262,
    final double? size263,
    final double? size264,
    final double? size265,
    final double? size266,
    final double? size267,
    final double? size268,
    final double? size269,
    final double? size270,
    final double? size271,
    final double? size272,
    final double? size273,
    final double? size274,
    final double? size275,
    final double? size276,
    final double? size277,
    final double? size278,
    final double? size279,
    final double? size280,
    final double? size281,
    final double? size282,
    final double? size283,
    final double? size284,
    final double? size285,
    final double? size286,
    final double? size287,
    final double? size288,
    final double? size289,
    final double? size290,
    final double? size291,
    final double? size292,
    final double? size293,
    final double? size294,
    final double? size295,
    final double? size296,
    final double? size297,
    final double? size298,
    final double? size299,
    final double? size300,
    final double? size301,
    final double? size302,
    final double? size303,
    final double? size304,
    final double? size305,
    final double? size306,
    final double? size307,
    final double? size308,
    final double? size309,
    final double? size310,
    final double? size311,
    final double? size312,
    final double? size313,
    final double? size314,
    final double? size315,
    final double? size316,
    final double? size317,
    final double? size318,
    final double? size319,
    final double? size320,
    final double? size321,
    final double? size322,
    final double? size323,
    final double? size324,
    final double? size325,
    final double? size326,
    final double? size327,
    final double? size328,
    final double? size329,
    final double? size330,
    final double? size331,
    final double? size332,
    final double? size333,
    final double? size334,
    final double? size335,
    final double? size336,
    final double? size337,
    final double? size338,
    final double? size339,
    final double? size340,
    final double? size341,
    final double? size342,
    final double? size343,
    final double? size344,
    final double? size345,
    final double? size346,
    final double? size347,
    final double? size348,
    final double? size349,
    final double? size350,
    final double? size351,
    final double? size352,
    final double? size353,
    final double? size354,
    final double? size355,
    final double? size356,
    final double? size357,
    final double? size358,
    final double? size359,
    final double? size360,
    final double? size361,
    final double? size362,
    final double? size363,
    final double? size364,
    final double? size365,
    final double? size366,
    final double? size367,
    final double? size368,
    final double? size369,
    final double? size370,
    final double? size371,
    final double? size372,
    final double? size373,
    final double? size374,
    final double? size375,
    final double? size376,
    final double? size377,
    final double? size378,
    final double? size379,
    final double? size380,
    final double? size381,
    final double? size382,
    final double? size383,
    final double? size384,
    final double? size385,
    final double? size386,
    final double? size387,
    final double? size388,
    final double? size389,
    final double? size390,
    final double? size391,
    final double? size392,
    final double? size393,
    final double? size394,
    final double? size395,
    final double? size396,
    final double? size397,
    final double? size398,
    final double? size399,
    final double? size400,
    final double? size401,
    final double? size402,
    final double? size403,
    final double? size404,
    final double? size405,
    final double? size406,
    final double? size407,
    final double? size408,
    final double? size409,
    final double? size410,
    final double? size411,
    final double? size412,
    final double? size413,
    final double? size414,
    final double? size415,
    final double? size416,
    final double? size417,
    final double? size418,
    final double? size419,
    final double? size420,
    final double? size421,
    final double? size422,
    final double? size423,
    final double? size424,
    final double? size425,
    final double? size426,
    final double? size427,
    final double? size428,
    final double? size429,
    final double? size430,
    final double? size431,
    final double? size432,
    final double? size433,
    final double? size434,
    final double? size435,
    final double? size436,
    final double? size437,
    final double? size438,
    final double? size439,
    final double? size440,
    final double? size441,
    final double? size442,
    final double? size443,
    final double? size444,
    final double? size445,
    final double? size446,
    final double? size447,
    final double? size448,
    final double? size449,
    final double? size450,
    final double? size451,
    final double? size452,
    final double? size453,
    final double? size454,
    final double? size455,
    final double? size456,
    final double? size457,
    final double? size458,
    final double? size459,
    final double? size460,
    final double? size461,
    final double? size462,
    final double? size463,
    final double? size464,
    final double? size465,
    final double? size466,
    final double? size467,
    final double? size468,
    final double? size469,
    final double? size470,
    final double? size471,
    final double? size472,
    final double? size473,
    final double? size474,
    final double? size475,
    final double? size476,
    final double? size477,
    final double? size478,
    final double? size479,
    final double? size480,
    final double? size481,
    final double? size482,
    final double? size483,
    final double? size484,
    final double? size485,
    final double? size486,
    final double? size487,
    final double? size488,
    final double? size489,
    final double? size490,
    final double? size491,
    final double? size492,
    final double? size493,
    final double? size494,
    final double? size495,
    final double? size496,
    final double? size497,
    final double? size498,
    final double? size499,
    final double? size500,
    final double? size501,
    final double? size502,
    final double? size503,
    final double? size504,
    final double? size505,
    final double? size506,
    final double? size507,
    final double? size508,
    final double? size509,
    final double? size510,
    final double? size511,
    final double? size512,
    final double? size513,
    final double? size514,
    final double? size515,
    final double? size516,
    final double? size517,
    final double? size518,
    final double? size519,
    final double? size520,
    final double? size521,
    final double? size522,
    final double? size523,
    final double? size524,
    final double? size525,
    final double? size526,
    final double? size527,
    final double? size528,
    final double? size529,
    final double? size530,
    final double? size531,
    final double? size532,
    final double? size533,
    final double? size534,
    final double? size535,
    final double? size536,
    final double? size537,
    final double? size538,
    final double? size539,
    final double? size540,
    final double? size541,
    final double? size542,
    final double? size543,
    final double? size544,
    final double? size545,
    final double? size546,
    final double? size547,
    final double? size548,
    final double? size549,
    final double? size550,
    final double? size551,
    final double? size552,
    final double? size553,
    final double? size554,
    final double? size555,
    final double? size556,
    final double? size557,
    final double? size558,
    final double? size559,
    final double? size560,
    final double? size561,
    final double? size562,
    final double? size563,
    final double? size564,
    final double? size565,
    final double? size566,
    final double? size567,
    final double? size568,
    final double? size569,
    final double? size570,
    final double? size571,
    final double? size572,
    final double? size573,
    final double? size574,
    final double? size575,
    final double? size576,
    final double? size577,
    final double? size578,
    final double? size579,
    final double? size580,
    final double? size581,
    final double? size582,
    final double? size583,
    final double? size584,
    final double? size585,
    final double? size586,
    final double? size587,
    final double? size588,
    final double? size589,
    final double? size590,
    final double? size591,
    final double? size592,
    final double? size593,
    final double? size594,
    final double? size595,
    final double? size596,
    final double? size597,
    final double? size598,
    final double? size599,
    final double? size600,
    final double? size601,
    final double? size602,
    final double? size603,
    final double? size604,
    final double? size605,
    final double? size606,
    final double? size607,
    final double? size608,
    final double? size609,
    final double? size610,
    final double? size611,
    final double? size612,
    final double? size613,
    final double? size614,
    final double? size615,
    final double? size616,
    final double? size617,
    final double? size618,
    final double? size619,
    final double? size620,
    final double? size621,
    final double? size622,
    final double? size623,
    final double? size624,
    final double? size625,
    final double? size626,
    final double? size627,
    final double? size628,
    final double? size629,
    final double? size630,
    final double? size631,
    final double? size632,
    final double? size633,
    final double? size634,
    final double? size635,
    final double? size636,
    final double? size637,
    final double? size638,
    final double? size639,
    final double? size640,
    final double? size641,
    final double? size642,
    final double? size643,
    final double? size644,
    final double? size645,
    final double? size646,
    final double? size647,
    final double? size648,
    final double? size649,
    final double? size650,
    final double? size651,
    final double? size652,
    final double? size653,
    final double? size654,
    final double? size655,
    final double? size656,
    final double? size657,
    final double? size658,
    final double? size659,
    final double? size660,
    final double? size661,
    final double? size662,
    final double? size663,
    final double? size664,
    final double? size665,
    final double? size666,
    final double? size667,
    final double? size668,
    final double? size669,
    final double? size670,
    final double? size671,
    final double? size672,
    final double? size673,
    final double? size674,
    final double? size675,
    final double? size676,
    final double? size677,
    final double? size678,
    final double? size679,
    final double? size680,
    final double? size681,
    final double? size682,
    final double? size683,
    final double? size684,
    final double? size685,
    final double? size686,
    final double? size687,
    final double? size688,
    final double? size689,
    final double? size690,
    final double? size691,
    final double? size692,
    final double? size693,
    final double? size694,
    final double? size695,
    final double? size696,
    final double? size697,
    final double? size698,
    final double? size699,
    final double? size700,
    final double? size701,
    final double? size702,
    final double? size703,
    final double? size704,
    final double? size705,
    final double? size706,
    final double? size707,
    final double? size708,
    final double? size709,
    final double? size710,
    final double? size711,
    final double? size712,
    final double? size713,
    final double? size714,
    final double? size715,
    final double? size716,
    final double? size717,
    final double? size718,
    final double? size719,
    final double? size720,
    final double? size721,
    final double? size722,
    final double? size723,
    final double? size724,
    final double? size725,
    final double? size726,
    final double? size727,
    final double? size728,
    final double? size729,
    final double? size730,
    final double? size731,
    final double? size732,
    final double? size733,
    final double? size734,
    final double? size735,
    final double? size736,
    final double? size737,
    final double? size738,
    final double? size739,
    final double? size740,
    final double? size741,
    final double? size742,
    final double? size743,
    final double? size744,
    final double? size745,
    final double? size746,
    final double? size747,
    final double? size748,
    final double? size749,
    final double? size750,
    final double? size751,
    final double? size752,
    final double? size753,
    final double? size754,
    final double? size755,
    final double? size756,
    final double? size757,
    final double? size758,
    final double? size759,
    final double? size760,
    final double? size761,
    final double? size762,
    final double? size763,
    final double? size764,
    final double? size765,
    final double? size766,
    final double? size767,
    final double? size768,
    final double? size769,
    final double? size770,
    final double? size771,
    final double? size772,
    final double? size773,
    final double? size774,
    final double? size775,
    final double? size776,
    final double? size777,
    final double? size778,
    final double? size779,
    final double? size780,
    final double? size781,
    final double? size782,
    final double? size783,
    final double? size784,
    final double? size785,
    final double? size786,
    final double? size787,
    final double? size788,
    final double? size789,
    final double? size790,
    final double? size791,
    final double? size792,
    final double? size793,
    final double? size794,
    final double? size795,
    final double? size796,
    final double? size797,
    final double? size798,
    final double? size799,
    final double? size800,
    final double? size801,
    final double? size802,
    final double? size803,
    final double? size804,
    final double? size805,
    final double? size806,
    final double? size807,
    final double? size808,
    final double? size809,
    final double? size810,
    final double? size811,
    final double? size812,
    final double? size813,
    final double? size814,
    final double? size815,
    final double? size816,
    final double? size817,
    final double? size818,
    final double? size819,
    final double? size820,
    final double? size821,
    final double? size822,
    final double? size823,
    final double? size824,
    final double? size825,
    final double? size826,
    final double? size827,
    final double? size828,
    final double? size829,
    final double? size830,
    final double? size831,
    final double? size832,
    final double? size833,
    final double? size834,
    final double? size835,
    final double? size836,
    final double? size837,
    final double? size838,
    final double? size839,
    final double? size840,
    final double? size841,
    final double? size842,
    final double? size843,
    final double? size844,
    final double? size845,
    final double? size846,
    final double? size847,
    final double? size848,
    final double? size849,
    final double? size850,
    final double? size851,
    final double? size852,
    final double? size853,
    final double? size854,
    final double? size855,
    final double? size856,
    final double? size857,
    final double? size858,
    final double? size859,
    final double? size860,
    final double? size861,
    final double? size862,
    final double? size863,
    final double? size864,
    final double? size865,
    final double? size866,
    final double? size867,
    final double? size868,
    final double? size869,
    final double? size870,
    final double? size871,
    final double? size872,
    final double? size873,
    final double? size874,
    final double? size875,
    final double? size876,
    final double? size877,
    final double? size878,
    final double? size879,
    final double? size880,
    final double? size881,
    final double? size882,
    final double? size883,
    final double? size884,
    final double? size885,
    final double? size886,
    final double? size887,
    final double? size888,
    final double? size889,
    final double? size890,
    final double? size891,
    final double? size892,
    final double? size893,
    final double? size894,
    final double? size895,
    final double? size896,
    final double? size897,
    final double? size898,
    final double? size899,
    final double? size900,
    final double? size901,
    final double? size902,
    final double? size903,
    final double? size904,
    final double? size905,
    final double? size906,
    final double? size907,
    final double? size908,
    final double? size909,
    final double? size910,
    final double? size911,
    final double? size912,
    final double? size913,
    final double? size914,
    final double? size915,
    final double? size916,
    final double? size917,
    final double? size918,
    final double? size919,
    final double? size920,
    final double? size921,
    final double? size922,
    final double? size923,
    final double? size924,
    final double? size925,
    final double? size926,
    final double? size927,
    final double? size928,
    final double? size929,
    final double? size930,
    final double? size931,
    final double? size932,
    final double? size933,
    final double? size934,
    final double? size935,
    final double? size936,
    final double? size937,
    final double? size938,
    final double? size939,
    final double? size940,
    final double? size941,
    final double? size942,
    final double? size943,
    final double? size944,
    final double? size945,
    final double? size946,
    final double? size947,
    final double? size948,
    final double? size949,
    final double? size950,
    final double? size951,
    final double? size952,
    final double? size953,
    final double? size954,
    final double? size955,
    final double? size956,
    final double? size957,
    final double? size958,
    final double? size959,
    final double? size960,
    final double? size961,
    final double? size962,
    final double? size963,
    final double? size964,
    final double? size965,
    final double? size966,
    final double? size967,
    final double? size968,
    final double? size969,
    final double? size970,
    final double? size971,
    final double? size972,
    final double? size973,
    final double? size974,
    final double? size975,
    final double? size976,
    final double? size977,
    final double? size978,
    final double? size979,
    final double? size980,
    final double? size981,
    final double? size982,
    final double? size983,
    final double? size984,
    final double? size985,
    final double? size986,
    final double? size987,
    final double? size988,
    final double? size989,
    final double? size990,
    final double? size991,
    final double? size992,
    final double? size993,
    final double? size994,
    final double? size995,
    final double? size996,
    final double? size997,
    final double? size998,
    final double? size999,
  }) =>
      AppSizeExtension(
        sizePoint72: sizePoint72,
        sizePoint5: sizePoint5,
        sizePoint7: sizePoint7,
        size0: size0,
        size1: size1 ?? this.size1,
        size2: size2 ?? this.size2,
        size3: size3 ?? this.size3,
        size4: size4 ?? this.size4,
        size5: size5 ?? this.size5,
        size6: size6 ?? this.size6,
        size7: size7 ?? this.size7,
        size8: size8 ?? this.size8,
        size9: size9 ?? this.size9,
        size10: size10 ?? this.size10,
        size11: size11 ?? this.size11,
        size12: size12 ?? this.size12,
        size13: size13 ?? this.size13,
        size14: size14 ?? this.size14,
        size15: size15 ?? this.size15,
        size16: size16 ?? this.size16,
        size17: size17 ?? this.size17,
        size18: size18 ?? this.size18,
        size19: size19 ?? this.size19,
        size20: size20 ?? this.size20,
        size21: size21 ?? this.size21,
        size22: size22 ?? this.size22,
        size23: size23 ?? this.size23,
        size24: size24 ?? this.size24,
        size25: size25 ?? this.size25,
        size26: size26 ?? this.size26,
        size27: size27 ?? this.size27,
        size28: size28 ?? this.size28,
        size29: size29 ?? this.size29,
        size30: size30 ?? this.size30,
        size31: size31 ?? this.size31,
        size32: size32 ?? this.size32,
        size33: size33 ?? this.size33,
        size34: size34 ?? this.size34,
        size35: size35 ?? this.size35,
        size36: size36 ?? this.size36,
        size37: size37 ?? this.size37,
        size38: size38 ?? this.size38,
        size39: size39 ?? this.size39,
        size40: size40 ?? this.size40,
        size41: size41 ?? this.size41,
        size42: size42 ?? this.size42,
        size43: size43 ?? this.size43,
        size44: size44 ?? this.size44,
        size45: size45 ?? this.size45,
        size46: size46 ?? this.size46,
        size47: size47 ?? this.size47,
        size48: size48 ?? this.size48,
        size49: size49 ?? this.size49,
        size50: size50 ?? this.size50,
        size51: size51 ?? this.size51,
        size52: size52 ?? this.size52,
        size53: size53 ?? this.size53,
        size54: size54 ?? this.size54,
        size55: size55 ?? this.size55,
        size56: size56 ?? this.size56,
        size57: size57 ?? this.size57,
        size58: size58 ?? this.size58,
        size59: size59 ?? this.size59,
        size60: size60 ?? this.size60,
        size61: size61 ?? this.size61,
        size62: size62 ?? this.size62,
        size63: size63 ?? this.size63,
        size64: size64 ?? this.size64,
        size65: size65 ?? this.size65,
        size66: size66 ?? this.size66,
        size67: size67 ?? this.size67,
        size68: size68 ?? this.size68,
        size69: size69 ?? this.size69,
        size70: size70 ?? this.size70,
        size71: size71 ?? this.size71,
        size72: size72 ?? this.size72,
        size73: size73 ?? this.size73,
        size74: size74 ?? this.size74,
        size75: size75 ?? this.size75,
        size76: size76 ?? this.size76,
        size77: size77 ?? this.size77,
        size78: size78 ?? this.size78,
        size79: size79 ?? this.size79,
        size80: size80 ?? this.size80,
        size81: size81 ?? this.size81,
        size82: size82 ?? this.size82,
        size83: size83 ?? this.size83,
        size84: size84 ?? this.size84,
        size85: size85 ?? this.size85,
        size86: size86 ?? this.size86,
        size87: size87 ?? this.size87,
        size88: size88 ?? this.size88,
        size89: size89 ?? this.size89,
        size90: size90 ?? this.size90,
        size91: size91 ?? this.size91,
        size92: size92 ?? this.size92,
        size93: size93 ?? this.size93,
        size94: size94 ?? this.size94,
        size95: size95 ?? this.size95,
        size96: size96 ?? this.size96,
        size97: size97 ?? this.size97,
        size98: size98 ?? this.size98,
        size99: size99 ?? this.size99,
        size100: size100 ?? this.size100,
        size101: size101 ?? this.size101,
        size102: size102 ?? this.size102,
        size103: size103 ?? this.size103,
        size104: size104 ?? this.size104,
        size105: size105 ?? this.size105,
        size106: size106 ?? this.size106,
        size107: size107 ?? this.size107,
        size108: size108 ?? this.size108,
        size109: size109 ?? this.size109,
        size110: size110 ?? this.size110,
        size111: size111 ?? this.size111,
        size112: size112 ?? this.size112,
        size113: size113 ?? this.size113,
        size114: size114 ?? this.size114,
        size115: size115 ?? this.size115,
        size116: size116 ?? this.size116,
        size117: size117 ?? this.size117,
        size118: size118 ?? this.size118,
        size119: size119 ?? this.size119,
        size120: size120 ?? this.size120,
        size121: size121 ?? this.size121,
        size122: size122 ?? this.size122,
        size123: size123 ?? this.size123,
        size124: size124 ?? this.size124,
        size125: size125 ?? this.size125,
        size126: size126 ?? this.size126,
        size127: size127 ?? this.size127,
        size128: size128 ?? this.size128,
        size129: size129 ?? this.size129,
        size130: size130 ?? this.size130,
        size131: size131 ?? this.size131,
        size132: size132 ?? this.size132,
        size133: size133 ?? this.size133,
        size134: size134 ?? this.size134,
        size135: size135 ?? this.size135,
        size136: size136 ?? this.size136,
        size137: size137 ?? this.size137,
        size138: size138 ?? this.size138,
        size139: size139 ?? this.size139,
        size140: size140 ?? this.size140,
        size141: size141 ?? this.size141,
        size142: size142 ?? this.size142,
        size143: size143 ?? this.size143,
        size144: size144 ?? this.size144,
        size145: size145 ?? this.size145,
        size146: size146 ?? this.size146,
        size147: size147 ?? this.size147,
        size148: size148 ?? this.size148,
        size149: size149 ?? this.size149,
        size150: size150 ?? this.size150,
        size151: size151 ?? this.size151,
        size152: size152 ?? this.size152,
        size153: size153 ?? this.size153,
        size154: size154 ?? this.size154,
        size155: size155 ?? this.size155,
        size156: size156 ?? this.size156,
        size157: size157 ?? this.size157,
        size158: size158 ?? this.size158,
        size159: size159 ?? this.size159,
        size160: size160 ?? this.size160,
        size161: size161 ?? this.size161,
        size162: size162 ?? this.size162,
        size163: size163 ?? this.size163,
        size164: size164 ?? this.size164,
        size165: size165 ?? this.size165,
        size166: size166 ?? this.size166,
        size167: size167 ?? this.size167,
        size168: size168 ?? this.size168,
        size169: size169 ?? this.size169,
        size170: size170 ?? this.size170,
        size171: size171 ?? this.size171,
        size172: size172 ?? this.size172,
        size173: size173 ?? this.size173,
        size174: size174 ?? this.size174,
        size175: size175 ?? this.size175,
        size176: size176 ?? this.size176,
        size177: size177 ?? this.size177,
        size178: size178 ?? this.size178,
        size179: size179 ?? this.size179,
        size180: size180 ?? this.size180,
        size181: size181 ?? this.size181,
        size182: size182 ?? this.size182,
        size183: size183 ?? this.size183,
        size184: size184 ?? this.size184,
        size185: size185 ?? this.size185,
        size186: size186 ?? this.size186,
        size187: size187 ?? this.size187,
        size188: size188 ?? this.size188,
        size189: size189 ?? this.size189,
        size190: size190 ?? this.size190,
        size191: size191 ?? this.size191,
        size192: size192 ?? this.size192,
        size193: size193 ?? this.size193,
        size194: size194 ?? this.size194,
        size195: size195 ?? this.size195,
        size196: size196 ?? this.size196,
        size197: size197 ?? this.size197,
        size198: size198 ?? this.size198,
        size199: size199 ?? this.size199,
        size200: size200 ?? this.size200,
        size201: size201 ?? this.size201,
        size202: size202 ?? this.size202,
        size203: size203 ?? this.size203,
        size204: size204 ?? this.size204,
        size205: size205 ?? this.size205,
        size206: size206 ?? this.size206,
        size207: size207 ?? this.size207,
        size208: size208 ?? this.size208,
        size209: size209 ?? this.size209,
        size210: size210 ?? this.size210,
        size211: size211 ?? this.size211,
        size212: size212 ?? this.size212,
        size213: size213 ?? this.size213,
        size214: size214 ?? this.size214,
        size215: size215 ?? this.size215,
        size216: size216 ?? this.size216,
        size217: size217 ?? this.size217,
        size218: size218 ?? this.size218,
        size219: size219 ?? this.size219,
        size220: size220 ?? this.size220,
        size221: size221 ?? this.size221,
        size222: size222 ?? this.size222,
        size223: size223 ?? this.size223,
        size224: size224 ?? this.size224,
        size225: size225 ?? this.size225,
        size226: size226 ?? this.size226,
        size227: size227 ?? this.size227,
        size228: size228 ?? this.size228,
        size229: size229 ?? this.size229,
        size230: size230 ?? this.size230,
        size231: size231 ?? this.size231,
        size232: size232 ?? this.size232,
        size233: size233 ?? this.size233,
        size234: size234 ?? this.size234,
        size235: size235 ?? this.size235,
        size236: size236 ?? this.size236,
        size237: size237 ?? this.size237,
        size238: size238 ?? this.size238,
        size239: size239 ?? this.size239,
        size240: size240 ?? this.size240,
        size241: size241 ?? this.size241,
        size242: size242 ?? this.size242,
        size243: size243 ?? this.size243,
        size244: size244 ?? this.size244,
        size245: size245 ?? this.size245,
        size246: size246 ?? this.size246,
        size247: size247 ?? this.size247,
        size248: size248 ?? this.size248,
        size249: size249 ?? this.size249,
        size250: size250 ?? this.size250,
        size251: size251 ?? this.size251,
        size252: size252 ?? this.size252,
        size253: size253 ?? this.size253,
        size254: size254 ?? this.size254,
        size255: size255 ?? this.size255,
        size256: size256 ?? this.size256,
        size257: size257 ?? this.size257,
        size258: size258 ?? this.size258,
        size259: size259 ?? this.size259,
        size260: size260 ?? this.size260,
        size261: size261 ?? this.size261,
        size262: size262 ?? this.size262,
        size263: size263 ?? this.size263,
        size264: size264 ?? this.size264,
        size265: size265 ?? this.size265,
        size266: size266 ?? this.size266,
        size267: size267 ?? this.size267,
        size268: size268 ?? this.size268,
        size269: size269 ?? this.size269,
        size270: size270 ?? this.size270,
        size271: size271 ?? this.size271,
        size272: size272 ?? this.size272,
        size273: size273 ?? this.size273,
        size274: size274 ?? this.size274,
        size275: size275 ?? this.size275,
        size276: size276 ?? this.size276,
        size277: size277 ?? this.size277,
        size278: size278 ?? this.size278,
        size279: size279 ?? this.size279,
        size280: size280 ?? this.size280,
        size281: size281 ?? this.size281,
        size282: size282 ?? this.size282,
        size283: size283 ?? this.size283,
        size284: size284 ?? this.size284,
        size285: size285 ?? this.size285,
        size286: size286 ?? this.size286,
        size287: size287 ?? this.size287,
        size288: size288 ?? this.size288,
        size289: size289 ?? this.size289,
        size290: size290 ?? this.size290,
        size291: size291 ?? this.size291,
        size292: size292 ?? this.size292,
        size293: size293 ?? this.size293,
        size294: size294 ?? this.size294,
        size295: size295 ?? this.size295,
        size296: size296 ?? this.size296,
        size297: size297 ?? this.size297,
        size298: size298 ?? this.size298,
        size299: size299 ?? this.size299,
        size300: size300 ?? this.size300,
        size301: size301 ?? this.size301,
        size302: size302 ?? this.size302,
        size303: size303 ?? this.size303,
        size304: size304 ?? this.size304,
        size305: size305 ?? this.size305,
        size306: size306 ?? this.size306,
        size307: size307 ?? this.size307,
        size308: size308 ?? this.size308,
        size309: size309 ?? this.size309,
        size310: size310 ?? this.size310,
        size311: size311 ?? this.size311,
        size312: size312 ?? this.size312,
        size313: size313 ?? this.size313,
        size314: size314 ?? this.size314,
        size315: size315 ?? this.size315,
        size316: size316 ?? this.size316,
        size317: size317 ?? this.size317,
        size318: size318 ?? this.size318,
        size319: size319 ?? this.size319,
        size320: size320 ?? this.size320,
        size321: size321 ?? this.size321,
        size322: size322 ?? this.size322,
        size323: size323 ?? this.size323,
        size324: size324 ?? this.size324,
        size325: size325 ?? this.size325,
        size326: size326 ?? this.size326,
        size327: size327 ?? this.size327,
        size328: size328 ?? this.size328,
        size329: size329 ?? this.size329,
        size330: size330 ?? this.size330,
        size331: size331 ?? this.size331,
        size332: size332 ?? this.size332,
        size333: size333 ?? this.size333,
        size334: size334 ?? this.size334,
        size335: size335 ?? this.size335,
        size336: size336 ?? this.size336,
        size337: size337 ?? this.size337,
        size338: size338 ?? this.size338,
        size339: size339 ?? this.size339,
        size340: size340 ?? this.size340,
        size341: size341 ?? this.size341,
        size342: size342 ?? this.size342,
        size343: size343 ?? this.size343,
        size344: size344 ?? this.size344,
        size345: size345 ?? this.size345,
        size346: size346 ?? this.size346,
        size347: size347 ?? this.size347,
        size348: size348 ?? this.size348,
        size349: size349 ?? this.size349,
        size350: size350 ?? this.size350,
        size351: size351 ?? this.size351,
        size352: size352 ?? this.size352,
        size353: size353 ?? this.size353,
        size354: size354 ?? this.size354,
        size355: size355 ?? this.size355,
        size356: size356 ?? this.size356,
        size357: size357 ?? this.size357,
        size358: size358 ?? this.size358,
        size359: size359 ?? this.size359,
        size360: size360 ?? this.size360,
        size361: size361 ?? this.size361,
        size362: size362 ?? this.size362,
        size363: size363 ?? this.size363,
        size364: size364 ?? this.size364,
        size365: size365 ?? this.size365,
        size366: size366 ?? this.size366,
        size367: size367 ?? this.size367,
        size368: size368 ?? this.size368,
        size369: size369 ?? this.size369,
        size370: size370 ?? this.size370,
        size371: size371 ?? this.size371,
        size372: size372 ?? this.size372,
        size373: size373 ?? this.size373,
        size374: size374 ?? this.size374,
        size375: size375 ?? this.size375,
        size376: size376 ?? this.size376,
        size377: size377 ?? this.size377,
        size378: size378 ?? this.size378,
        size379: size379 ?? this.size379,
        size380: size380 ?? this.size380,
        size381: size381 ?? this.size381,
        size382: size382 ?? this.size382,
        size383: size383 ?? this.size383,
        size384: size384 ?? this.size384,
        size385: size385 ?? this.size385,
        size386: size386 ?? this.size386,
        size387: size387 ?? this.size387,
        size388: size388 ?? this.size388,
        size389: size389 ?? this.size389,
        size390: size390 ?? this.size390,
        size391: size391 ?? this.size391,
        size392: size392 ?? this.size392,
        size393: size393 ?? this.size393,
        size394: size394 ?? this.size394,
        size395: size395 ?? this.size395,
        size396: size396 ?? this.size396,
        size397: size397 ?? this.size397,
        size398: size398 ?? this.size398,
        size399: size399 ?? this.size399,
        size400: size400 ?? this.size400,
        size401: size401 ?? this.size401,
        size402: size402 ?? this.size402,
        size403: size403 ?? this.size403,
        size404: size404 ?? this.size404,
        size405: size405 ?? this.size405,
        size406: size406 ?? this.size406,
        size407: size407 ?? this.size407,
        size408: size408 ?? this.size408,
        size409: size409 ?? this.size409,
        size410: size410 ?? this.size410,
        size411: size411 ?? this.size411,
        size412: size412 ?? this.size412,
        size413: size413 ?? this.size413,
        size414: size414 ?? this.size414,
        size415: size415 ?? this.size415,
        size416: size416 ?? this.size416,
        size417: size417 ?? this.size417,
        size418: size418 ?? this.size418,
        size419: size419 ?? this.size419,
        size420: size420 ?? this.size420,
        size421: size421 ?? this.size421,
        size422: size422 ?? this.size422,
        size423: size423 ?? this.size423,
        size424: size424 ?? this.size424,
        size425: size425 ?? this.size425,
        size426: size426 ?? this.size426,
        size427: size427 ?? this.size427,
        size428: size428 ?? this.size428,
        size429: size429 ?? this.size429,
        size430: size430 ?? this.size430,
        size431: size431 ?? this.size431,
        size432: size432 ?? this.size432,
        size433: size433 ?? this.size433,
        size434: size434 ?? this.size434,
        size435: size435 ?? this.size435,
        size436: size436 ?? this.size436,
        size437: size437 ?? this.size437,
        size438: size438 ?? this.size438,
        size439: size439 ?? this.size439,
        size440: size440 ?? this.size440,
        size441: size441 ?? this.size441,
        size442: size442 ?? this.size442,
        size443: size443 ?? this.size443,
        size444: size444 ?? this.size444,
        size445: size445 ?? this.size445,
        size446: size446 ?? this.size446,
        size447: size447 ?? this.size447,
        size448: size448 ?? this.size448,
        size449: size449 ?? this.size449,
        size450: size450 ?? this.size450,
        size451: size451 ?? this.size451,
        size452: size452 ?? this.size452,
        size453: size453 ?? this.size453,
        size454: size454 ?? this.size454,
        size455: size455 ?? this.size455,
        size456: size456 ?? this.size456,
        size457: size457 ?? this.size457,
        size458: size458 ?? this.size458,
        size459: size459 ?? this.size459,
        size460: size460 ?? this.size460,
        size461: size461 ?? this.size461,
        size462: size462 ?? this.size462,
        size463: size463 ?? this.size463,
        size464: size464 ?? this.size464,
        size465: size465 ?? this.size465,
        size466: size466 ?? this.size466,
        size467: size467 ?? this.size467,
        size468: size468 ?? this.size468,
        size469: size469 ?? this.size469,
        size470: size470 ?? this.size470,
        size471: size471 ?? this.size471,
        size472: size472 ?? this.size472,
        size473: size473 ?? this.size473,
        size474: size474 ?? this.size474,
        size475: size475 ?? this.size475,
        size476: size476 ?? this.size476,
        size477: size477 ?? this.size477,
        size478: size478 ?? this.size478,
        size479: size479 ?? this.size479,
        size480: size480 ?? this.size480,
        size481: size481 ?? this.size481,
        size482: size482 ?? this.size482,
        size483: size483 ?? this.size483,
        size484: size484 ?? this.size484,
        size485: size485 ?? this.size485,
        size486: size486 ?? this.size486,
        size487: size487 ?? this.size487,
        size488: size488 ?? this.size488,
        size489: size489 ?? this.size489,
        size490: size490 ?? this.size490,
        size491: size491 ?? this.size491,
        size492: size492 ?? this.size492,
        size493: size493 ?? this.size493,
        size494: size494 ?? this.size494,
        size495: size495 ?? this.size495,
        size496: size496 ?? this.size496,
        size497: size497 ?? this.size497,
        size498: size498 ?? this.size498,
        size499: size499 ?? this.size499,
        size500: size500 ?? this.size500,
        size501: size501 ?? this.size501,
        size502: size502 ?? this.size502,
        size503: size503 ?? this.size503,
        size504: size504 ?? this.size504,
        size505: size505 ?? this.size505,
        size506: size506 ?? this.size506,
        size507: size507 ?? this.size507,
        size508: size508 ?? this.size508,
        size509: size509 ?? this.size509,
        size510: size510 ?? this.size510,
        size511: size511 ?? this.size511,
        size512: size512 ?? this.size512,
        size513: size513 ?? this.size513,
        size514: size514 ?? this.size514,
        size515: size515 ?? this.size515,
        size516: size516 ?? this.size516,
        size517: size517 ?? this.size517,
        size518: size518 ?? this.size518,
        size519: size519 ?? this.size519,
        size520: size520 ?? this.size520,
        size521: size521 ?? this.size521,
        size522: size522 ?? this.size522,
        size523: size523 ?? this.size523,
        size524: size524 ?? this.size524,
        size525: size525 ?? this.size525,
        size526: size526 ?? this.size526,
        size527: size527 ?? this.size527,
        size528: size528 ?? this.size528,
        size529: size529 ?? this.size529,
        size530: size530 ?? this.size530,
        size531: size531 ?? this.size531,
        size532: size532 ?? this.size532,
        size533: size533 ?? this.size533,
        size534: size534 ?? this.size534,
        size535: size535 ?? this.size535,
        size536: size536 ?? this.size536,
        size537: size537 ?? this.size537,
        size538: size538 ?? this.size538,
        size539: size539 ?? this.size539,
        size540: size540 ?? this.size540,
        size541: size541 ?? this.size541,
        size542: size542 ?? this.size542,
        size543: size543 ?? this.size543,
        size544: size544 ?? this.size544,
        size545: size545 ?? this.size545,
        size546: size546 ?? this.size546,
        size547: size547 ?? this.size547,
        size548: size548 ?? this.size548,
        size549: size549 ?? this.size549,
        size550: size550 ?? this.size550,
        size551: size551 ?? this.size551,
        size552: size552 ?? this.size552,
        size553: size553 ?? this.size553,
        size554: size554 ?? this.size554,
        size555: size555 ?? this.size555,
        size556: size556 ?? this.size556,
        size557: size557 ?? this.size557,
        size558: size558 ?? this.size558,
        size559: size559 ?? this.size559,
        size560: size560 ?? this.size560,
        size561: size561 ?? this.size561,
        size562: size562 ?? this.size562,
        size563: size563 ?? this.size563,
        size564: size564 ?? this.size564,
        size565: size565 ?? this.size565,
        size566: size566 ?? this.size566,
        size567: size567 ?? this.size567,
        size568: size568 ?? this.size568,
        size569: size569 ?? this.size569,
        size570: size570 ?? this.size570,
        size571: size571 ?? this.size571,
        size572: size572 ?? this.size572,
        size573: size573 ?? this.size573,
        size574: size574 ?? this.size574,
        size575: size575 ?? this.size575,
        size576: size576 ?? this.size576,
        size577: size577 ?? this.size577,
        size578: size578 ?? this.size578,
        size579: size579 ?? this.size579,
        size580: size580 ?? this.size580,
        size581: size581 ?? this.size581,
        size582: size582 ?? this.size582,
        size583: size583 ?? this.size583,
        size584: size584 ?? this.size584,
        size585: size585 ?? this.size585,
        size586: size586 ?? this.size586,
        size587: size587 ?? this.size587,
        size588: size588 ?? this.size588,
        size589: size589 ?? this.size589,
        size590: size590 ?? this.size590,
        size591: size591 ?? this.size591,
        size592: size592 ?? this.size592,
        size593: size593 ?? this.size593,
        size594: size594 ?? this.size594,
        size595: size595 ?? this.size595,
        size596: size596 ?? this.size596,
        size597: size597 ?? this.size597,
        size598: size598 ?? this.size598,
        size599: size599 ?? this.size599,
        size600: size600 ?? this.size600,
        size601: size601 ?? this.size601,
        size602: size602 ?? this.size602,
        size603: size603 ?? this.size603,
        size604: size604 ?? this.size604,
        size605: size605 ?? this.size605,
        size606: size606 ?? this.size606,
        size607: size607 ?? this.size607,
        size608: size608 ?? this.size608,
        size609: size609 ?? this.size609,
        size610: size610 ?? this.size610,
        size611: size611 ?? this.size611,
        size612: size612 ?? this.size612,
        size613: size613 ?? this.size613,
        size614: size614 ?? this.size614,
        size615: size615 ?? this.size615,
        size616: size616 ?? this.size616,
        size617: size617 ?? this.size617,
        size618: size618 ?? this.size618,
        size619: size619 ?? this.size619,
        size620: size620 ?? this.size620,
        size621: size621 ?? this.size621,
        size622: size622 ?? this.size622,
        size623: size623 ?? this.size623,
        size624: size624 ?? this.size624,
        size625: size625 ?? this.size625,
        size626: size626 ?? this.size626,
        size627: size627 ?? this.size627,
        size628: size628 ?? this.size628,
        size629: size629 ?? this.size629,
        size630: size630 ?? this.size630,
        size631: size631 ?? this.size631,
        size632: size632 ?? this.size632,
        size633: size633 ?? this.size633,
        size634: size634 ?? this.size634,
        size635: size635 ?? this.size635,
        size636: size636 ?? this.size636,
        size637: size637 ?? this.size637,
        size638: size638 ?? this.size638,
        size639: size639 ?? this.size639,
        size640: size640 ?? this.size640,
        size641: size641 ?? this.size641,
        size642: size642 ?? this.size642,
        size643: size643 ?? this.size643,
        size644: size644 ?? this.size644,
        size645: size645 ?? this.size645,
        size646: size646 ?? this.size646,
        size647: size647 ?? this.size647,
        size648: size648 ?? this.size648,
        size649: size649 ?? this.size649,
        size650: size650 ?? this.size650,
        size651: size651 ?? this.size651,
        size652: size652 ?? this.size652,
        size653: size653 ?? this.size653,
        size654: size654 ?? this.size654,
        size655: size655 ?? this.size655,
        size656: size656 ?? this.size656,
        size657: size657 ?? this.size657,
        size658: size658 ?? this.size658,
        size659: size659 ?? this.size659,
        size660: size660 ?? this.size660,
        size661: size661 ?? this.size661,
        size662: size662 ?? this.size662,
        size663: size663 ?? this.size663,
        size664: size664 ?? this.size664,
        size665: size665 ?? this.size665,
        size666: size666 ?? this.size666,
        size667: size667 ?? this.size667,
        size668: size668 ?? this.size668,
        size669: size669 ?? this.size669,
        size670: size670 ?? this.size670,
        size671: size671 ?? this.size671,
        size672: size672 ?? this.size672,
        size673: size673 ?? this.size673,
        size674: size674 ?? this.size674,
        size675: size675 ?? this.size675,
        size676: size676 ?? this.size676,
        size677: size677 ?? this.size677,
        size678: size678 ?? this.size678,
        size679: size679 ?? this.size679,
        size680: size680 ?? this.size680,
        size681: size681 ?? this.size681,
        size682: size682 ?? this.size682,
        size683: size683 ?? this.size683,
        size684: size684 ?? this.size684,
        size685: size685 ?? this.size685,
        size686: size686 ?? this.size686,
        size687: size687 ?? this.size687,
        size688: size688 ?? this.size688,
        size689: size689 ?? this.size689,
        size690: size690 ?? this.size690,
        size691: size691 ?? this.size691,
        size692: size692 ?? this.size692,
        size693: size693 ?? this.size693,
        size694: size694 ?? this.size694,
        size695: size695 ?? this.size695,
        size696: size696 ?? this.size696,
        size697: size697 ?? this.size697,
        size698: size698 ?? this.size698,
        size699: size699 ?? this.size699,
        size700: size700 ?? this.size700,
        size701: size701 ?? this.size701,
        size702: size702 ?? this.size702,
        size703: size703 ?? this.size703,
        size704: size704 ?? this.size704,
        size705: size705 ?? this.size705,
        size706: size706 ?? this.size706,
        size707: size707 ?? this.size707,
        size708: size708 ?? this.size708,
        size709: size709 ?? this.size709,
        size710: size710 ?? this.size710,
        size711: size711 ?? this.size711,
        size712: size712 ?? this.size712,
        size713: size713 ?? this.size713,
        size714: size714 ?? this.size714,
        size715: size715 ?? this.size715,
        size716: size716 ?? this.size716,
        size717: size717 ?? this.size717,
        size718: size718 ?? this.size718,
        size719: size719 ?? this.size719,
        size720: size720 ?? this.size720,
        size721: size721 ?? this.size721,
        size722: size722 ?? this.size722,
        size723: size723 ?? this.size723,
        size724: size724 ?? this.size724,
        size725: size725 ?? this.size725,
        size726: size726 ?? this.size726,
        size727: size727 ?? this.size727,
        size728: size728 ?? this.size728,
        size729: size729 ?? this.size729,
        size730: size730 ?? this.size730,
        size731: size731 ?? this.size731,
        size732: size732 ?? this.size732,
        size733: size733 ?? this.size733,
        size734: size734 ?? this.size734,
        size735: size735 ?? this.size735,
        size736: size736 ?? this.size736,
        size737: size737 ?? this.size737,
        size738: size738 ?? this.size738,
        size739: size739 ?? this.size739,
        size740: size740 ?? this.size740,
        size741: size741 ?? this.size741,
        size742: size742 ?? this.size742,
        size743: size743 ?? this.size743,
        size744: size744 ?? this.size744,
        size745: size745 ?? this.size745,
        size746: size746 ?? this.size746,
        size747: size747 ?? this.size747,
        size748: size748 ?? this.size748,
        size749: size749 ?? this.size749,
        size750: size750 ?? this.size750,
        size751: size751 ?? this.size751,
        size752: size752 ?? this.size752,
        size753: size753 ?? this.size753,
        size754: size754 ?? this.size754,
        size755: size755 ?? this.size755,
        size756: size756 ?? this.size756,
        size757: size757 ?? this.size757,
        size758: size758 ?? this.size758,
        size759: size759 ?? this.size759,
        size760: size760 ?? this.size760,
        size761: size761 ?? this.size761,
        size762: size762 ?? this.size762,
        size763: size763 ?? this.size763,
        size764: size764 ?? this.size764,
        size765: size765 ?? this.size765,
        size766: size766 ?? this.size766,
        size767: size767 ?? this.size767,
        size768: size768 ?? this.size768,
        size769: size769 ?? this.size769,
        size770: size770 ?? this.size770,
        size771: size771 ?? this.size771,
        size772: size772 ?? this.size772,
        size773: size773 ?? this.size773,
        size774: size774 ?? this.size774,
        size775: size775 ?? this.size775,
        size776: size776 ?? this.size776,
        size777: size777 ?? this.size777,
        size778: size778 ?? this.size778,
        size779: size779 ?? this.size779,
        size780: size780 ?? this.size780,
        size781: size781 ?? this.size781,
        size782: size782 ?? this.size782,
        size783: size783 ?? this.size783,
        size784: size784 ?? this.size784,
        size785: size785 ?? this.size785,
        size786: size786 ?? this.size786,
        size787: size787 ?? this.size787,
        size788: size788 ?? this.size788,
        size789: size789 ?? this.size789,
        size790: size790 ?? this.size790,
        size791: size791 ?? this.size791,
        size792: size792 ?? this.size792,
        size793: size793 ?? this.size793,
        size794: size794 ?? this.size794,
        size795: size795 ?? this.size795,
        size796: size796 ?? this.size796,
        size797: size797 ?? this.size797,
        size798: size798 ?? this.size798,
        size799: size799 ?? this.size799,
        size800: size800 ?? this.size800,
        size801: size801 ?? this.size801,
        size802: size802 ?? this.size802,
        size803: size803 ?? this.size803,
        size804: size804 ?? this.size804,
        size805: size805 ?? this.size805,
        size806: size806 ?? this.size806,
        size807: size807 ?? this.size807,
        size808: size808 ?? this.size808,
        size809: size809 ?? this.size809,
        size810: size810 ?? this.size810,
        size811: size811 ?? this.size811,
        size812: size812 ?? this.size812,
        size813: size813 ?? this.size813,
        size814: size814 ?? this.size814,
        size815: size815 ?? this.size815,
        size816: size816 ?? this.size816,
        size817: size817 ?? this.size817,
        size818: size818 ?? this.size818,
        size819: size819 ?? this.size819,
        size820: size820 ?? this.size820,
        size821: size821 ?? this.size821,
        size822: size822 ?? this.size822,
        size823: size823 ?? this.size823,
        size824: size824 ?? this.size824,
        size825: size825 ?? this.size825,
        size826: size826 ?? this.size826,
        size827: size827 ?? this.size827,
        size828: size828 ?? this.size828,
        size829: size829 ?? this.size829,
        size830: size830 ?? this.size830,
        size831: size831 ?? this.size831,
        size832: size832 ?? this.size832,
        size833: size833 ?? this.size833,
        size834: size834 ?? this.size834,
        size835: size835 ?? this.size835,
        size836: size836 ?? this.size836,
        size837: size837 ?? this.size837,
        size838: size838 ?? this.size838,
        size839: size839 ?? this.size839,
        size840: size840 ?? this.size840,
        size841: size841 ?? this.size841,
        size842: size842 ?? this.size842,
        size843: size843 ?? this.size843,
        size844: size844 ?? this.size844,
        size845: size845 ?? this.size845,
        size846: size846 ?? this.size846,
        size847: size847 ?? this.size847,
        size848: size848 ?? this.size848,
        size849: size849 ?? this.size849,
        size850: size850 ?? this.size850,
        size851: size851 ?? this.size851,
        size852: size852 ?? this.size852,
        size853: size853 ?? this.size853,
        size854: size854 ?? this.size854,
        size855: size855 ?? this.size855,
        size856: size856 ?? this.size856,
        size857: size857 ?? this.size857,
        size858: size858 ?? this.size858,
        size859: size859 ?? this.size859,
        size860: size860 ?? this.size860,
        size861: size861 ?? this.size861,
        size862: size862 ?? this.size862,
        size863: size863 ?? this.size863,
        size864: size864 ?? this.size864,
        size865: size865 ?? this.size865,
        size866: size866 ?? this.size866,
        size867: size867 ?? this.size867,
        size868: size868 ?? this.size868,
        size869: size869 ?? this.size869,
        size870: size870 ?? this.size870,
        size871: size871 ?? this.size871,
        size872: size872 ?? this.size872,
        size873: size873 ?? this.size873,
        size874: size874 ?? this.size874,
        size875: size875 ?? this.size875,
        size876: size876 ?? this.size876,
        size877: size877 ?? this.size877,
        size878: size878 ?? this.size878,
        size879: size879 ?? this.size879,
        size880: size880 ?? this.size880,
        size881: size881 ?? this.size881,
        size882: size882 ?? this.size882,
        size883: size883 ?? this.size883,
        size884: size884 ?? this.size884,
        size885: size885 ?? this.size885,
        size886: size886 ?? this.size886,
        size887: size887 ?? this.size887,
        size888: size888 ?? this.size888,
        size889: size889 ?? this.size889,
        size890: size890 ?? this.size890,
        size891: size891 ?? this.size891,
        size892: size892 ?? this.size892,
        size893: size893 ?? this.size893,
        size894: size894 ?? this.size894,
        size895: size895 ?? this.size895,
        size896: size896 ?? this.size896,
        size897: size897 ?? this.size897,
        size898: size898 ?? this.size898,
        size899: size899 ?? this.size899,
        size900: size900 ?? this.size900,
        size901: size901 ?? this.size901,
        size902: size902 ?? this.size902,
        size903: size903 ?? this.size903,
        size904: size904 ?? this.size904,
        size905: size905 ?? this.size905,
        size906: size906 ?? this.size906,
        size907: size907 ?? this.size907,
        size908: size908 ?? this.size908,
        size909: size909 ?? this.size909,
        size910: size910 ?? this.size910,
        size911: size911 ?? this.size911,
        size912: size912 ?? this.size912,
        size913: size913 ?? this.size913,
        size914: size914 ?? this.size914,
        size915: size915 ?? this.size915,
        size916: size916 ?? this.size916,
        size917: size917 ?? this.size917,
        size918: size918 ?? this.size918,
        size919: size919 ?? this.size919,
        size920: size920 ?? this.size920,
        size921: size921 ?? this.size921,
        size922: size922 ?? this.size922,
        size923: size923 ?? this.size923,
        size924: size924 ?? this.size924,
        size925: size925 ?? this.size925,
        size926: size926 ?? this.size926,
        size927: size927 ?? this.size927,
        size928: size928 ?? this.size928,
        size929: size929 ?? this.size929,
        size930: size930 ?? this.size930,
        size931: size931 ?? this.size931,
        size932: size932 ?? this.size932,
        size933: size933 ?? this.size933,
        size934: size934 ?? this.size934,
        size935: size935 ?? this.size935,
        size936: size936 ?? this.size936,
        size937: size937 ?? this.size937,
        size938: size938 ?? this.size938,
        size939: size939 ?? this.size939,
        size940: size940 ?? this.size940,
        size941: size941 ?? this.size941,
        size942: size942 ?? this.size942,
        size943: size943 ?? this.size943,
        size944: size944 ?? this.size944,
        size945: size945 ?? this.size945,
        size946: size946 ?? this.size946,
        size947: size947 ?? this.size947,
        size948: size948 ?? this.size948,
        size949: size949 ?? this.size949,
        size950: size950 ?? this.size950,
        size951: size951 ?? this.size951,
        size952: size952 ?? this.size952,
        size953: size953 ?? this.size953,
        size954: size954 ?? this.size954,
        size955: size955 ?? this.size955,
        size956: size956 ?? this.size956,
        size957: size957 ?? this.size957,
        size958: size958 ?? this.size958,
        size959: size959 ?? this.size959,
        size960: size960 ?? this.size960,
        size961: size961 ?? this.size961,
        size962: size962 ?? this.size962,
        size963: size963 ?? this.size963,
        size964: size964 ?? this.size964,
        size965: size965 ?? this.size965,
        size966: size966 ?? this.size966,
        size967: size967 ?? this.size967,
        size968: size968 ?? this.size968,
        size969: size969 ?? this.size969,
        size970: size970 ?? this.size970,
        size971: size971 ?? this.size971,
        size972: size972 ?? this.size972,
        size973: size973 ?? this.size973,
        size974: size974 ?? this.size974,
        size975: size975 ?? this.size975,
        size976: size976 ?? this.size976,
        size977: size977 ?? this.size977,
        size978: size978 ?? this.size978,
        size979: size979 ?? this.size979,
        size980: size980 ?? this.size980,
        size981: size981 ?? this.size981,
        size982: size982 ?? this.size982,
        size983: size983 ?? this.size983,
        size984: size984 ?? this.size984,
        size985: size985 ?? this.size985,
        size986: size986 ?? this.size986,
        size987: size987 ?? this.size987,
        size988: size988 ?? this.size988,
        size989: size989 ?? this.size989,
        size990: size990 ?? this.size990,
        size991: size991 ?? this.size991,
        size992: size992 ?? this.size992,
        size993: size993 ?? this.size993,
        size994: size994 ?? this.size994,
        size995: size995 ?? this.size995,
        size996: size996 ?? this.size996,
        size997: size997 ?? this.size997,
        size998: size998 ?? this.size998,
        size999: size999 ?? this.size999,
      );

  @override
  ThemeExtension<AppSizeExtension> lerp(
    covariant final ThemeExtension<AppSizeExtension>? other,
    final double t,
  ) {
    throw UnimplementedError();
  }
}
