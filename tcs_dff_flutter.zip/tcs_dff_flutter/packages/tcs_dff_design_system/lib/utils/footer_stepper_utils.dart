enum FooterStepperVariants {
  defaultFooter,
  footerWithBack,
  footerWithButtonCaption,
  footerWithCheckbox,
  footerWithNoteWidget,
}
