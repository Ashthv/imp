enum ImageType {
  networkImage,
  assetImage,
}
