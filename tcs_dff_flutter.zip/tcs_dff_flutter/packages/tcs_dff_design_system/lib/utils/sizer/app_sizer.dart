library app_sizer;

import 'dart:math' as math;

import 'package:flutter/widgets.dart';

part 'sizer_extension.dart';
part 'sizer_configuration.dart';
part 'sizer_initializer.dart';
