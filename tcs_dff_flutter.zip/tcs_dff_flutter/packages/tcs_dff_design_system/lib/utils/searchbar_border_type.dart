enum SearchbarBorderType {
  border,
  borderless
}