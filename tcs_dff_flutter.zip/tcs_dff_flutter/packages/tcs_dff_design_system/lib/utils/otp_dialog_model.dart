// import 'package:flutter/material.dart';

// class OtpDialogData {
//    String title;
//    String subTitle;
//    int pinLength;
//    String resendOtpText;
//    Duration resendOtpDuration;
//    Function(String pin) resendOtpcallback;
//    String titleBorderButton;
//    VoidCallback borderButtonCallback;
//    String titleNormalButton;
//    Function(String pin) normalButtonCallback;
//    String errorText;
//    bool isValidPin;

//   OtpDialogData({
//     required this.title,
//     required this.subTitle,
//     required this.pinLength,
//     required this.resendOtpText,
//     required this.resendOtpDuration,
//     required this.resendOtpcallback,
//     required this.titleBorderButton,
//     required this.borderButtonCallback,
//     required this.titleNormalButton,
//     required this.normalButtonCallback,
//     required this.errorText,
//     required this.isValidPin,
//   });
// }