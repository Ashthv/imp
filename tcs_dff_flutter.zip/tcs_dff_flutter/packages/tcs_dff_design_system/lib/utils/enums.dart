
enum FileSourceType { frontCamera, backCamera, device }

enum UploadType { selfieOrProfile, selfie, document }