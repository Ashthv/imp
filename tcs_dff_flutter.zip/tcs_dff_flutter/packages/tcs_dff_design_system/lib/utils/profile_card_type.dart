enum ProfileCardType { defaultValue, mobile, infoText, email, accountNo, image }
