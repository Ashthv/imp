import 'package:flutter_contacts/flutter_contacts.dart';
 
typedef UserContact = Contact;
 