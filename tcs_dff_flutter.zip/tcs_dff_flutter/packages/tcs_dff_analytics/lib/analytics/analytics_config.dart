final defaultParameters = <String, dynamic>{
  'test': 'test',
  'string_parameter': 'string',
  'int_parameter': 42,
  'version': '1.0.4',
};
